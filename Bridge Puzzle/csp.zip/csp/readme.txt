The program cryptarith.py solves Cryptarithmetic problems
using a very basic Backtracking Search with no enhancements.

It can be run it by typing:

python3 cryptarith.py < puzzle1.in
python3 cryptarith.py < puzzle2.in

